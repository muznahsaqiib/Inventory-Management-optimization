CREATE TABLE order_history (
    order_id INT PRIMARY KEY IDENTITY(1,1),
    user_id INT,
    shipper_id INT,
    product_id varchar(10),
    name NVARCHAR(255),
    description NVARCHAR(MAX),
    price DECIMAL(10, 2),
    quantity INT,
    order_date DATETIME DEFAULT GETDATE(),
    delivery_date DATETIME,
    status NVARCHAR(20) DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Cancelled')),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (shipper_id) REFERENCES shippers(shipper_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);
