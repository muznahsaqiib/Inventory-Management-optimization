import pyodbc

def connect_to_database():
    try:
        # Defining the connection string
        conn = pyodbc.connect('Driver={SQL Server};'
                              'Server=DESKTOP-U9MLR5I\MSSQLSERVER06;'
                              'Database=Inventory;'
                              'Trusted_Connection=yes;')

        print("Connection successful!")
        return conn

    except Exception as e:
        print("Error connecting to SQL Server:", e)
        return None

def main_menu():
    print("INVENTORY STORE OPTIMIZATION")
    print('''1. Login as Admin
        2. Login as User''')
    choice = input("Select an option: ")
    return choice

def addProduct(conn):
    try:
        cursor = conn.cursor()

        # Automatically assign product ID for products
        cursor.execute("SELECT MAX(product_id) FROM products")
        max_id = cursor.fetchone()[0]

        if max_id:
            new_id = int(max_id[1:]) + 1
        else:
            new_id = 1

        new_id_str = 'P' + str(new_id).zfill(3)  # Format the new ID with leading zeros

        # Prompt the user to input product details
        name = input("Enter product name: ")

        # Construct SQL query to insert the product into products table
        sql_query_products = """
            INSERT INTO products (product_id, name)
            VALUES (?, ?)
        """

        # Execute the SQL query with parameters
        cursor.execute(sql_query_products, (new_id_str, name))

        # Prompt the user to input product details
        description = input("Enter product description: ")
        price = input("Enter product price: ")
        quantity = input("Enter product quantity: ")
        category_id = input("Enter category ID: ")

        # Construct SQL query to insert the product into products_P02 table
        sql_query_products_p02 = """
            INSERT INTO products_P02 (name, description, price, quantity, category_id)
            VALUES (?, ?, ?, ?, ?)
        """

        # Execute the SQL query with parameters
        cursor.execute(sql_query_products_p02, (name, description, price, quantity, category_id))

        conn.commit()  # Commit the transaction

        print("Product added successfully to both products and products_P02!")
    except Exception as e:
        print("Error adding product:", e)

def deleteProduct(conn):
    try:
        cursor = conn.cursor()

        # Prompt the user to input the product ID to delete
        product_id = input("Enter the product ID to delete: ")

        # Check if the product exists
        cursor.execute("SELECT * FROM products WHERE product_id = ?", (product_id,))
        product = cursor.fetchone()

        if product:
            # Delete the product from products table
            cursor.execute("DELETE FROM products WHERE product_id = ?", (product_id,))

            # Delete the product from products_P02 table
            cursor.execute("DELETE FROM products_P02 WHERE name = ?", (product['name'],))

            conn.commit()  # Commit the transaction

            print("Product deleted successfully from both products and products_P02!")
        else:
            print("Product not found.")
    except Exception as e:
        print("Error deleting product:", e)


def admin_login(conn):
    password = input("Enter Password: ")
    if password == '1502':
        print('Login successful!')
        addProduct(conn)  
    else:
        print("Incorrect password. Login authentication failed.")

def user_login():
    # Add user login functionality here
    pass

if __name__ == "__main__":
    conn = connect_to_database()
    if conn:
        choice = main_menu()
        if choice == '1':
            admin_login(conn)  # Pass connection object to admin_login function
        elif choice == '2':
            user_login()
        else:
            print("Invalid choice. Please select a valid option.")
        conn.close()
