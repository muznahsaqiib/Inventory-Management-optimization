CREATE TABLE Shippers (
    shipper_id INT PRIMARY KEY,
    shipper_name VARCHAR(100) NOT NULL,
    contact_info VARCHAR(255),
    delivery_preferences VARCHAR(255)
);
INSERT INTO Shippers (shipper_id, shipper_name, contact_info, delivery_preferences) 
VALUES 
    (1, 'Express Logistics', '123-456-7890', 'Fast delivery within 24 hours'),
    (2, 'Speedy Shipments', '555-555-5555', 'Guaranteed delivery within 48 hours'),
    (3, 'Reliable Couriers', '888-888-8888', 'Flexible delivery options, including same-day delivery'),
    (4, 'Swift Transport', '999-999-9999', 'Specializes in handling fragile items and sensitive shipments');
