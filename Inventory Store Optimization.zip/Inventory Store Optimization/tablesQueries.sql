CREATE TABLE categories (
    category_id varchar(10) PRIMARY KEY,
    name NVARCHAR(255)
);

CREATE TABLE suppliers (
    supplier_id varchar(10) PRIMARY KEY,
    supplier_name NVARCHAR(255)
);

CREATE TABLE supplier_S2 (
    name NVARCHAR(255) PRIMARY KEY,
    contact_info NVARCHAR(255)
);

CREATE TABLE products (
    product_id varchar(10) PRIMARY KEY,
    name NVARCHAR(255)
);

CREATE TABLE products_P02 (
    name NVARCHAR(255),
    description NVARCHAR(255),
    price DECIMAL(18, 2),
    quantity int,
    category_id varchar(10),
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    PRIMARY KEY (name) -- Assuming 'name' uniquely identifies products in this table
);

CREATE TABLE orders (
    order_id varchar(10) PRIMARY KEY,
    supplier_id varchar(10),
    order_date Date,
    expected_delivery Date,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
);

CREATE TABLE orderLineItems (
    orderline_id varchar(10) PRIMARY KEY,
    order_id varchar(10),
    product_id varchar(10),
    quantity int,
    unit_price DECIMAL(18, 2),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);

CREATE TABLE transactions (
    transaction_id varchar(10) PRIMARY KEY,
    product_id varchar(10),
    quantity int,
    transaction_date DATE,
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);
