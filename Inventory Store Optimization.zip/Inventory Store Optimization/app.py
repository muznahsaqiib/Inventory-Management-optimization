import datetime
import uuid
from flask import Flask, jsonify, redirect, render_template, request, session, url_for
import pyodbc

app = Flask(__name__)
app.secret_key = '1502'
def connect_to_database():
    try:
        conn = pyodbc.connect('Driver={SQL Server};'
                              'Server=DESKTOP-U9MLR5I\MSSQLSERVER06;'
                              'Database=Inventory;'
                              'Trusted_Connection=yes;')
        print("Connection successful!")
        return conn
    except Exception as e:
        print("Error connecting to SQL Server:", e)
        return None
    
                                                        #MAIN MENU
                                                                                                                                                                                                                                                                     
@app.route('/')
def homepage():
    return render_template('homepage.html')
@app.route('/main_menu')
def main_menu():
    return render_template('main_menu.html')
@app.route('/Aboutus')
def about_us():
    return render_template('Aboutus.html')



                                                       #ADD PRODUCT

@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        try:
            conn = connect_to_database()
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(product_id) FROM products")
            max_id = cursor.fetchone()[0]
            if max_id:
                new_id = int(max_id[1:]) + 1
            else:
                new_id = 1
            new_id_str = 'P' + str(new_id).zfill(3)  
            name = request.form['name']
            description = request.form['description']
            price = request.form['price']
            quantity = request.form['quantity']
            category_id = request.form['category_id']
            cursor.execute("INSERT INTO products (product_id, name) VALUES (?, ?)", (new_id_str, name))
            cursor.execute("INSERT INTO products_P02 (name, description, price, quantity, category_id) VALUES (?, ?, ?, ?, ?)",
                           (name, description, price, quantity, category_id))
            conn.commit() 
            return 'Product added successfully to both products and products_P02!'
        except Exception as e:
            return f'Error adding product: {e}'
        finally:
            conn.close()
    return render_template('add_product.html')

                                                      # DELETE PRODUCT

@app.route('/delete_product', methods=['GET', 'POST'])
def delete_product():
    if request.method == 'POST':
        try:
            conn = connect_to_database()
            cursor = conn.cursor()
            product_id = request.form['product_id']
            cursor.execute("SELECT COUNT(*) FROM products WHERE product_id = ?", (product_id,))
            product_exists = cursor.fetchone()[0]
            if product_exists == 0:
                return render_template('error.html', error='Product does not exist.')
            cursor.execute("DELETE FROM products WHERE product_id = ?", (product_id,))
            cursor.execute("DELETE FROM products_P02 WHERE name = ?", (product_id,))
            conn.commit() 
            return f'Product with ID {product_id} deleted successfully from both products and products_P02!'
        except Exception as e:
            return f'Error deleting product: {e}'
        finally:
            conn.close()
    return render_template('delete_product.html')


                                                 #UPDATE PRODUCT

@app.route('/update_product', methods=['GET', 'POST'])
def update_product():
    if request.method == 'POST':
        try:
            conn = connect_to_database()
            cursor = conn.cursor()
            product_id = request.form['product_id']
            name = request.form['name']
            description = request.form['description']
            price = request.form['price']
            quantity = request.form['quantity']
            category_id = request.form['category_id']
            
            # Check if the product ID exists
            cursor.execute("SELECT COUNT(*) FROM products WHERE product_id = ?", (product_id,))
            product_exists = cursor.fetchone()[0]
            if product_exists == 0:
                return render_template('error.html', error='Product does not exist in the table. Please provide a valid product ID for updating.')
            
            # Update product information
            cursor.execute("UPDATE products SET name=? WHERE product_id=?", (name, product_id))
            cursor.execute("UPDATE products_P02 SET description=?, price=?, quantity=?, category_id=? WHERE name=?", (description, price, quantity, category_id, name))
            
            conn.commit()
            return f'Product with ID {product_id} updated successfully!'
        except Exception as e:
            return f'Error updating product: {e}'
        finally:
            conn.close()
    return render_template('update_product.html')

                                              #search products by product_ID

@app.route('/search_product_by_id', methods=['GET', 'POST'])
def search_product_by_id():
    if request.method == 'POST':
        product_id = request.form['product_id']
        try:
            conn = connect_to_database()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT p.product_id, p.name, pp.description, pp.price, pp.quantity, pp.category_id ,pp.cost_price
                FROM products p
                JOIN products_P02 pp ON p.name = pp.name
                WHERE p.product_id = ?
            """, (product_id,))
            rows = cursor.fetchall()
            if not rows:
                return render_template('error.html', error='Product does not exist in the table. Please provide a valid product ID for searching.')
            products = []
            for row in rows:
                product = {
                    'product_id': row[0],
                    'name': row[1],
                    'description': row[2],
                    'price': row[3],
                    'quantity': row[4],
                    'category_id': row[5],
                    'cost_price':row[6]
                }
                products.append(product)
            conn.close()
            return render_template('product_search_results.html', products=products)
        except Exception as e:
            return render_template('error.html', error=f'Error searching products by ID: {e}')
    return render_template('search_product_by_id.html')



                                            # Route to display all products
                                            
@app.route('/view_all_products')
def view_all_products():
    try:
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("SELECT products.product_id, products.name, products_P02.description, products_P02.price, products_P02.category_id, products_P02.quantity,products_P02.cost_price FROM products INNER JOIN products_P02 ON products.name = products_P02.name")
        products = cursor.fetchall()
        conn.close()
        return render_template('view_all_products.html', products=products)
    except Exception as e:
        print(f'Error retrieving all products: {e}')
        return f'Error retrieving all products: {e}'                

                                             #ADD SUPPLIER

@app.route('/add_supplier', methods=['GET', 'POST'])
def add_supplier():
    if request.method == 'POST':
        try:
            conn = connect_to_database()
            cursor = conn.cursor()
            name = request.form['name']
            contact_info = request.form['contact_info']
            category_name = request.form['category_name']
            cursor.execute("SELECT MAX(supplier_id) FROM suppliers")
            max_id = cursor.fetchone()[0]
            if max_id:
                new_id = int(max_id[1:]) + 1
            else:
                new_id = 1
            new_supplier_id = 'S' + str(new_id).zfill(3)
            cursor.execute("SELECT MAX(category_id) FROM categories")
            max_cat_id = cursor.fetchone()[0]
            if max_cat_id:
                new_cat_id = int(max_cat_id[1:]) + 1
            else:
                new_cat_id = 1
            new_category_id = 'C' + str(new_cat_id).zfill(3)
            cursor.execute("INSERT INTO suppliers (supplier_id, supplier_name) VALUES (?, ?)",
                           (new_supplier_id, name))
            conn.commit()
            cursor.execute("INSERT INTO supplier_S2 (name, contact_info, category_id) VALUES (?, ?, ?)",
                           (name, contact_info, new_category_id))
            conn.commit()
            cursor.execute("INSERT INTO categories (category_id, name, supplier_id) VALUES (?, ?, ?)",
                           (new_category_id, category_name, new_supplier_id))
            conn.commit()
            return jsonify({'message': 'Supplier added successfully'})
        except Exception as e:
            return jsonify({'error': f'Error adding supplier: {e}'})
        finally:
            conn.close()
    return render_template('add_supplier.html')

                                                        #DELETE SUPPLIER


@app.route('/delete_supplier', methods=['GET','POST'])
def delete_supplier():
    if request.method == 'POST':
        try:
            conn = connect_to_database()
            cursor = conn.cursor()
            supplier_id = request.form['supplier_id']
            cursor.execute("SELECT COUNT(*) FROM suppliers WHERE supplier_id = ?", (supplier_id,))
            supplier_exists = cursor.fetchone()[0]
            if supplier_exists == 0:
                return render_template('error.html', error='Supplier with this ID does not exist in the records.')
            cursor.execute("SELECT supplier_name FROM suppliers WHERE supplier_id = ?", (supplier_id,))
            supplier_name = cursor.fetchone()[0]
            cursor.execute("SELECT category_id FROM supplier_S2 WHERE name = ?", (supplier_name,))
            category_id = cursor.fetchone()[0]
            cursor.execute("DELETE FROM suppliers WHERE supplier_id = ?", (supplier_id,))
            cursor.execute("DELETE FROM supplier_S2 WHERE name = ?", (supplier_name,))
            cursor.execute("DELETE FROM categories WHERE category_id = ?", (category_id,))
            conn.commit()
            conn.close()
            return render_template('delete_supplier.html', message='Supplier, category, and associated records deleted successfully')
        except Exception as e:
            return render_template('error.html', error=f'Error deleting supplier and associated records: {e}')
    return render_template('delete_supplier.html')
 

                                                #SEARCH SUPPLIER
@app.route('/search_suppliers', methods=['GET', 'POST'])
def search_suppliers():
    if request.method == 'POST':
        try:
            conn = connect_to_database()
            cursor = conn.cursor()
            supplier_id = request.form['supplier_id']
            cursor.execute("SELECT * FROM suppliers WHERE supplier_id = ?", (supplier_id,))
            supplier = cursor.fetchone()
            if supplier:
                cursor.execute("SELECT * FROM supplier_S2 WHERE name = ?", (supplier[1],))
                supplier_details = cursor.fetchone()
                if supplier_details:
                    supplier_data = {
                        'supplier_id': supplier[0],
                        'supplier_name': supplier[1],
                        'contact_info': supplier_details[1],
                        'category_id': supplier_details[2]
                    }
                    return render_template('supplier_details.html', supplier=supplier_data)
                else:
                    return render_template('error.html', error='Supplier details not found in supplier_S2 table')
            else:
                return render_template('error.html', error='Supplier does not exist')
        except Exception as e:
            return render_template('error.html', error=f'Error searching supplier: {e}')
        finally:
            conn.close()
    return render_template('search_suppliers.html')


                                                    #UPDATE SUPPLIER

@app.route('/update_supplier', methods=['GET', 'POST'])
def update_supplier():
    if request.method == 'POST':
        try:
            conn = connect_to_database()
            cursor = conn.cursor()
            supplier_id = request.form['supplier_id']
            name = request.form['name']
            contact_info = request.form['contact_info']
            category_name = request.form['category_name']
            cursor.execute("SELECT COUNT(*) FROM suppliers WHERE supplier_id = ?", (supplier_id,))
            supplier_exists = cursor.fetchone()[0]
            if supplier_exists == 0:
                return render_template('error.html', error='Supplier does not exist in the table. Please provide a valid supplier ID for updating.')
            cursor.execute("UPDATE suppliers SET supplier_name = ? WHERE supplier_id = ?", (name, supplier_id))
            cursor.execute("UPDATE supplier_S2 SET contact_info = ? WHERE name = ?", (contact_info, name))
            cursor.execute("UPDATE categories SET name = ? WHERE supplier_id = ?", (category_name, supplier_id))
            conn.commit()
            return jsonify({'message': 'Supplier updated successfully'})
        except Exception as e:
            return jsonify({'error': f'Error updating supplier: {e}'})
        finally:
            conn.close()
    return render_template('update_supplier.html')


                                        #ALL SUPPLIERS

@app.route('/view_all_suppliers')
def view_all_suppliers():
    try:
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("SELECT s.supplier_id, s.supplier_name, s2.contact_info, s2.category_id FROM suppliers s LEFT JOIN supplier_S2 s2 ON s.supplier_name = s2.name")
        suppliers = cursor.fetchall()
        conn.close()
        return render_template('view_all_suppliers.html', suppliers=suppliers)
    except Exception as e:
        return f'Error retrieving all suppliers: {e}'
    

                                            #SHIPPERS
                                            #ADD SHIPPER

@app.route('/add_shipper', methods=['GET', 'POST'])
def add_shipper():
    if request.method == 'POST':
        try:
            shipper_name = request.form['shipper_name']
            contact_info = request.form['contact_info']
            delivery_preferences = request.form['delivery_preferences']
            conn = connect_to_database()
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(shipper_id) FROM Shippers")
            max_shipper_id = cursor.fetchone()[0]
            next_shipper_id = max_shipper_id + 1 if max_shipper_id else 1
            cursor.execute("INSERT INTO Shippers (shipper_id, shipper_name, contact_info, delivery_preferences) VALUES (?, ?, ?, ?)",
                           (next_shipper_id, shipper_name, contact_info, delivery_preferences))
            conn.commit()
            return render_template('add_shipper.html', success=True, message="Shipper added successfully")
        except Exception as e:
            return render_template('error.html', error=f'Error adding shipper: {str(e)}')
        finally:
            if conn:
                conn.close()
    else:
        return render_template('add_shipper.html')
    
                                            #DELETE SHIPPER

@app.route('/delete_shipper', methods=['GET', 'POST'])
def delete_shipper():
    if request.method == 'POST':
        try:
            shipper_id = request.form['shipper_id']
            conn = connect_to_database()
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM Shippers WHERE shipper_id = ?", (shipper_id,))
            shipper_exists = cursor.fetchone()[0]
            if shipper_exists == 0:
                return jsonify({'success': False, 'error': 'Shipper does not exist.'})
            cursor.execute("DELETE FROM Shippers WHERE shipper_id = ?", (shipper_id,))
            conn.commit()
            return jsonify({'success': True, 'message': 'Shipper deleted successfully'})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
        finally:
            if conn:
                conn.close()
    else:
        return render_template('delete_shipper.html')
    
                                            #UPDATE SHIPPER

@app.route('/update_shipper', methods=['GET', 'POST'])
def update_shipper():
    if request.method == 'POST':
        try:
            shipper_id = request.form['shipper_id']
            shipper_name = request.form['shipper_name']
            contact_info = request.form['contact_info']
            delivery_preferences = request.form['delivery_preferences']
            
            conn = connect_to_database()
            cursor = conn.cursor()
            
            # Check if the shipper exists
            cursor.execute("SELECT COUNT(*) FROM Shippers WHERE shipper_id = ?", (shipper_id,))
            shipper_exists = cursor.fetchone()[0]
            if shipper_exists == 0:
                return jsonify({'success': False, 'error': 'Shipper does not exist.'})
            
            # Update shipper details
            cursor.execute("UPDATE Shippers SET shipper_name=?, contact_info=?, delivery_preferences=? WHERE shipper_id=?",
                           (shipper_name, contact_info, delivery_preferences, shipper_id))
            conn.commit()
            
            return jsonify({'success': True, 'message': 'Shipper updated successfully'})
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)})
        finally:
            if conn:
                conn.close()
    else:
        return render_template('update_shipper.html')
    
                                    #SEARCH SHIPPER

@app.route('/search_shipper', methods=['GET', 'POST'])
def search_shipper():
    if request.method == 'POST':
        try:
            shipper_name = request.form['shipper_name']
            conn = connect_to_database()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Shippers WHERE shipper_name LIKE ?", ('%' + shipper_name + '%',))
            shippers = cursor.fetchall()
            return render_template('search_results.html', shippers=shippers)
        except Exception as e:
            return render_template('error.html', error=f'Error searching shipper: {str(e)}')
        finally:
            if conn:
                conn.close()
    else:
        return render_template('search_shipper.html')


                                        #VIEW ALL SHIPPERS
                                     
@app.route('/view_all_shippers')
def view_all_shippers():
    try:
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM Shippers")
        shippers = cursor.fetchall()
        return render_template('view_all_shippers.html', shippers=shippers)
    except Exception as e:
        return render_template('error.html', error=f'Error fetching shippers: {str(e)}')
    finally:
        if conn:
            conn.close()

            
                                                #SET THRESHOLD FOR ALL PRODUCTS

@app.route('/set_min_threshold', methods=['GET', 'POST'])
def set_min_threshold():
    if request.method == 'POST':
        try:
            threshold = int(request.form['threshold'])
            conn = connect_to_database()
            cursor = conn.cursor()
            cursor.execute("UPDATE products_P02 SET min_threshold = ?", (threshold,))
            conn.commit()
            conn.close()
            return redirect(url_for('monitor_stock_levels', threshold=threshold))
        except Exception as e:
            return f'Error setting minimum threshold: {e}'
    return render_template('set_min_threshold.html')


 

                                        #MONITOR STOCK LEVELS
@app.route('/monitor_stock_levels')
def monitor_stock_levels():
    try:
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT products.product_id, products.name, products_P02.quantity
            FROM products
            INNER JOIN products_P02 ON products.name = products_P02.name
            WHERE products_P02.quantity < min_threshold  /* Assuming you have a min_threshold column in your products_P02 table */
        """)
        low_stock_products = cursor.fetchall()
        conn.close()
        return render_template('monitor_stock_levels.html', low_stock_products=low_stock_products)

    except Exception as e:
        return f'Error retrieving stock levels: {e}'

                                    
                                            #GENERATE INVENTORY REPORT FOR ADMIN

@app.route('/generate_inventory_report')
def generate_inventory_report():
    try:
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.product_id, pp.name AS product_name, pp.description, pp.price, pp.quantity,
                   s.supplier_id, s.supplier_name, ss.contact_info, c.name AS category_name
            FROM products AS p
            JOIN products_P02 AS pp ON p.name = pp.name
            JOIN suppliers AS s ON pp.name = s.supplier_name
            JOIN supplier_S2 AS ss ON s.supplier_name = ss.name
            JOIN categories AS c ON pp.category_id = c.category_id
        """)
        inventory_report = cursor.fetchall()
        conn.close()
        return render_template('generate_inventory_report.html', inventory_data=inventory_report)
    except Exception as e:
        return f'Error generating inventory report: {e}'

                                                        #SEARCH PRODUCT

@app.route('/search', methods=['GET', 'POST'])
def search():
    try:
        query = request.args.get('query')
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.product_id, p.name, pp.description, pp.price, pp.quantity, pp.category_id
            FROM products p
            JOIN products_P02 pp ON p.name = pp.name
            WHERE p.name LIKE ?
        """, ('%' + query + '%',))
        rows = cursor.fetchall()
        products = []
        for row in rows:
            product = dict(zip([column[0] for column in cursor.description], row))
            products.append(product)
        conn.close()
        return jsonify({'products': products})
    except Exception as e:
        print("Error searching products:", e)
        return jsonify({'error': f'Error searching products: {e}'})



                                                #REGISTER USER

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            conn = connect_to_database()
            cursor = conn.cursor()
            username = request.form['username']
            email = request.form['email']
            password = request.form['password']
            created_at = datetime.datetime.now()  
            cursor.execute("INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, ?)",
               (username, email, password, created_at))
            conn.commit()
            return 'User registered successfully!'
        except Exception as e:
            return f'Error registering user: {e}'
        finally:
            conn.close()
    return render_template('register.html')

                                                    # Login route

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            username = request.form['username']
            password = request.form['password']
            conn = connect_to_database()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
            user = cursor.fetchone()
            conn.close()
            if user:
                session['username'] = username  
                return redirect(url_for('homepage'))  
            else:
                return render_template('login.html', error='Invalid username or password')  
        except Exception as e:
            return f'Error during login: {e}'
    return render_template('login.html')

                                                    # Logout route

@app.route('/logout')
def logout():
    session.pop('username', None) 
    return redirect(url_for('homepage')) 

                                                    #ADD TO CART

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    try:
        if 'username' not in session:
            return jsonify({'success': False, 'error': 'Please login first to add items to the cart'})
        username = session['username'] 
        data = request.get_json()
        product_id = data['product_id']
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM users WHERE username = ?", (username,))
        user_id = cursor.fetchone()[0]
        cursor.execute("SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?", (user_id, product_id))
        existing_quantity = cursor.fetchone()
        if existing_quantity:
            new_quantity = existing_quantity[0] + 1
            cursor.execute("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?", (new_quantity, user_id, product_id))
        else:
            cursor.execute("INSERT INTO cart (user_id, product_id, quantity, timestamp) VALUES (?, ?, 1, GETDATE())", (user_id, product_id))
        cursor.execute("""
            UPDATE pp
            SET pp.quantity = pp.quantity - 1
            FROM products_P02 pp
            JOIN products p ON pp.name = p.name
            WHERE p.product_id = ?
        """, (product_id,))
        conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})
    finally:
        if conn:
            conn.close()


                                                        #REMOVE FROM CART

@app.route('/remove_from_cart', methods=['POST'])
def remove_from_cart():
    try:
        if 'username' not in session:
            return jsonify({'success': False, 'error': 'Please login first to remove items from the cart'})
        username = session['username'] 
        data = request.get_json()
        product_id = data['product_id']
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM users WHERE username = ?", (username,))
        user_id = cursor.fetchone()[0] 
        cursor.execute("SELECT quantity FROM cart WHERE user_id = ? AND product_id = ?", (user_id, product_id))
        existing_quantity = cursor.fetchone()
        if existing_quantity:
            current_quantity = existing_quantity[0]
            if current_quantity == 1:
                cursor.execute("DELETE FROM cart WHERE user_id = ? AND product_id = ?", (user_id, product_id))
            else:
                new_quantity = current_quantity - 1
                cursor.execute("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?", (new_quantity, user_id, product_id))
        else:
            return jsonify({'success': False, 'error': 'Item not found in the cart'})
        cursor.execute("""
            UPDATE pp
            SET pp.quantity = pp.quantity + 1
            FROM products_P02 pp
            JOIN products p ON pp.name = p.name
            WHERE p.product_id = ?
        """, (product_id,))
        conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})
    finally:
        if conn:
            conn.close()

                                                #VIEW CART

@app.route('/view_cart/<username>')
def view_cart(username):
    if 'username' not in session:
        return render_template('error.html', error='Please login first to see the cart')
    try:
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT c.user_id, p.product_id, p.name, pp.price, c.quantity
            FROM cart c
            JOIN users u ON c.user_id = u.user_id
            JOIN products p ON c.product_id = p.product_id
            JOIN products_P02 pp ON p.name = pp.name
            WHERE u.username = ?
        """, (username,))
        cart_items = cursor.fetchall()
        conn.close()
        total_price = sum(item[3] * item[4] for item in cart_items)
        return render_template('view_cart.html', cart_items=cart_items, total_price=total_price)
    except Exception as e:
        return f'Error retrieving cart items: {e}'



 
                                        # Route to display the list of shippers
@app.route('/select_shipper', methods=['GET'])
def select_shipper():
    try:
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("SELECT shipper_id, shipper_name FROM Shippers")
        shippers = cursor.fetchall()
        conn.close()
        return render_template('select_shipper.html', shippers=shippers)
    except Exception as e:
        return f'Error retrieving shippers: {e}'

                                        #order placements
@app.route('/place_order', methods=['POST'])
def place_order():
    try:
        if 'username' not in session:
            return render_template('error.html', error='Please login first to place an order')

        username = session['username']
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id FROM Users WHERE username = ?", (username,))
        user_id = cursor.fetchone()[0]

        shipper_id = request.form['shipper_id']
        cursor.execute("SELECT MAX(CAST(SUBSTRING(order_id, 2, LEN(order_id)) AS INT)) FROM orders")
        max_order_id = cursor.fetchone()[0]
        if max_order_id is None:
            max_order_id = 0
        new_order_id = 'O' + str(max_order_id + 1).zfill(3)
        order_date = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        expected_delivery = (datetime.datetime.now() + datetime.timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
        
        cursor.execute("INSERT INTO orders (order_id, shipper_id, order_date, expected_delivery, user_id) VALUES (?, ?, ?, ?, ?)",
                       (new_order_id, shipper_id, order_date, expected_delivery, user_id))
        
        cursor.execute("SELECT product_id, quantity FROM cart WHERE user_id = ?", (user_id,))
        cart_items = cursor.fetchall()
        
        cursor.execute("SELECT MAX(CAST(SUBSTRING(orderline_id, 2, LEN(orderline_id)) AS INT)) FROM orderlineitems")
        max_orderline_id = cursor.fetchone()[0]
        if max_orderline_id is None:
            max_orderline_id = 0

        orderline_counter = max_orderline_id + 1

        for product_id, quantity in cart_items:
            orderline_id = 'i' + str(orderline_counter).zfill(3)
            cursor.execute("""
    SELECT p.price 
    FROM products_P02 p
    INNER JOIN products pr ON p.name = pr.name
    WHERE pr.product_id = ?
""", (product_id,))
            unit_price = cursor.fetchone()[0]
            
            cursor.execute("INSERT INTO orderlineitems (orderline_id, order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ?, ?)",
                           (orderline_id, new_order_id, product_id, quantity, unit_price))
            orderline_counter += 1
        
        cursor.execute("INSERT INTO pending_orders (order_id, user_id) VALUES (?, ?)",
               (new_order_id, user_id))

        cursor.execute("DELETE FROM cart WHERE user_id = ?", (user_id,))
        
        conn.commit()
        conn.close()
        return render_template('pending_approval.html', order_id=new_order_id)
    except Exception as e:
        return f'Error placing order: {e}'

                                            #ORDER APPROVAL
@app.route('/admin/pending_orders', methods=['GET', 'POST'])
def pending_orders():
    try:
        if request.method == 'POST':
            action = request.form.get('action')
            order_id = request.form.get('order_id')
            if action == 'approve':
                conn = connect_to_database()
                cursor = conn.cursor()
                cursor.execute("DELETE FROM pending_orders WHERE order_id = ?", (order_id,))
                cursor.execute("UPDATE orders SET approved = 1 WHERE order_id = ?", (order_id,))
                conn.commit()

                conn.close()
                return redirect(url_for('pending_orders'))
            elif action == 'cancel':
                conn = connect_to_database()
                cursor = conn.cursor()
                cursor.execute("DELETE FROM orders WHERE order_id = ?", (order_id,))
                cursor.execute("DELETE FROM orderlineitems WHERE order_id = ?", (order_id,))
                cursor.execute("DELETE FROM pending_orders WHERE order_id = ?", (order_id,))
                conn.commit()
                conn.close()
                return redirect(url_for('pending_orders'))

        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("SELECT order_id, user_id FROM pending_orders")
        pending_orders = cursor.fetchall()
        conn.close()

        return render_template('pending_orders.html', pending_orders=pending_orders)
    except Exception as e:
        return f'Error processing pending orders: {e}'
    

def get_user_orders(username):
    try:
        conn = connect_to_database()
        if conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT o.order_id, o.order_date, o.expected_delivery,o.approved, u.username,
       oli.product_id, oli.quantity, oli.unit_price,
       p.name AS product_name
FROM orders o
INNER JOIN orderLineItems oli ON o.order_id = oli.order_id
INNER JOIN products p ON oli.product_id = p.product_id
INNER JOIN users u ON o.user_id = u.user_id
WHERE u.username = ?

            """, (username,))
            orders = cursor.fetchall()
            return orders
        else:
            print("Failed to connect to the database.")
            return None
    except Exception as e:
        print("Error fetching user orders:", e)
        return None
    finally:
        if conn:
            conn.close()

@app.route('/orders', methods=['GET'])
def display_orders():
    username = session.get('username')
    if username:
        orders = get_user_orders(username)
        if orders:
            return render_template('orders.html', orders=orders)
        else:
            return "No orders found for this user."
    else:
        return redirect(url_for('login')) 
    

                                        #TRANSACTION SLIPP


@app.route('/generate_slip', methods=['GET'])
def generate_slip():
    try:
        order_id = request.args.get('order_id')
        conn = connect_to_database()
        cursor = conn.cursor()
        cursor.execute("SELECT user_id, shipper_id FROM orders WHERE order_id = ?", (order_id,))
        user_id, shipper_id = cursor.fetchone()
        cursor.execute("SELECT username FROM Users WHERE user_id = ?", (user_id,))
        user_name = cursor.fetchone()[0]
        cursor.execute("SELECT product_id, quantity, unit_price FROM orderlineitems WHERE order_id = ?", (order_id,))
        order_line_items = cursor.fetchall()
        total_amount = sum(quantity * unit_price for product_id, quantity, unit_price in order_line_items)
        product_descriptions = ', '.join(f"{quantity} x {product_id}" for product_id, quantity, _ in order_line_items)
        cursor.execute("SELECT pp.category_id FROM products p JOIN products_P02 pp ON p.name = pp.name WHERE p.product_id = ?", (order_line_items[0][0],))
        category_id = cursor.fetchone()[0]
        cursor.execute("SELECT supplier_id FROM categories WHERE category_id = ?", (category_id,))
        supplier_id = cursor.fetchone()[0]
        cursor.execute("DELETE FROM Transactions WHERE order_id = ?", (order_id,))
        cursor.execute("DELETE FROM orderlineitems WHERE order_id = ?", (order_id,))
        cursor.execute("""
            INSERT INTO Transactions (order_id, user_id, user_name, shipper_id, supplier_id, transaction_date, total_amount, product_description)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP, ?, ?)
        """, (order_id, user_id, user_name, shipper_id, supplier_id, total_amount, product_descriptions))
        cursor.execute("DELETE FROM orders WHERE order_id = ?", (order_id,))
        conn.commit()
        conn.close()
        return render_template('transaction_slip.html', order_id=order_id)
    except Exception as e:
        return f'Error generating transaction slip: {e}'

if __name__ == "__main__":
    app.run(debug=True)
