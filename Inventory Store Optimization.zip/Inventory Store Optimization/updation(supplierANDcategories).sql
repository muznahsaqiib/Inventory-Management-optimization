

-- Update supplier_id in the categories table
UPDATE categories
SET supplier_id = 
    CASE 
        WHEN category_id = 'C001' THEN 'S001'
        WHEN category_id = 'C002' THEN 'S002'
        WHEN category_id = 'C003' THEN 'S003'
        WHEN category_id = 'C004' THEN 'S004'
        WHEN category_id = 'C005' THEN 'S005'
        WHEN category_id = 'C006' THEN 'S006'
        WHEN category_id = 'C007' THEN 'S007'
        WHEN category_id = 'C008' THEN 'S008'
        WHEN category_id = 'C009' THEN 'S009'
        WHEN category_id = 'C010' THEN 'S010'
        ELSE NULL  -- Add more conditions if necessary
    END;

-- Update category_id in the supplier_S2 table
UPDATE supplier_S2
SET category_id = 
    CASE 
        WHEN name = 'S001' THEN 'C001'
        WHEN name = 'S002' THEN 'C002'
        WHEN name = 'S003' THEN 'C003'
        WHEN name = 'S004' THEN 'C004'
        WHEN name = 'S005' THEN 'C005'
        WHEN name = 'S006' THEN 'C006'
        WHEN name = 'S007' THEN 'C007'
        WHEN name = 'S008' THEN 'C008'
        WHEN name = 'S009' THEN 'C009'
        WHEN name = 'S010' THEN 'C010'
        ELSE NULL  -- Add more conditions if necessary
    END;
